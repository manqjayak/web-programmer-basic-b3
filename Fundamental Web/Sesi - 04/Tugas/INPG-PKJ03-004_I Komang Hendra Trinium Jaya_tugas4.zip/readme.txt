Menghitung Luas dan Keliling Lingkaran
STORE "jariJari" with any value
STORE "luas" without value
STORE "keliling" without value

CALCULATE 3,14 times "jariJari" times "jariJari"
SET "luas" value with calculation result

CALCULATE 3,14 times "2" times "jariJari"
SET "keliling" value with calculation result

DISPLAY "luas"
DISPLAY "keliling"
